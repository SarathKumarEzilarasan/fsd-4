package com.example.springjmsdemo.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Email {
    private String to;
    private String body;
}

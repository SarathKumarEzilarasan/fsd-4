import "./App.css";
import Header from "./Header";
import Content from "./Content";
import Footer from "./Footer";
import { useEffect, useState } from "react";
import AddItem from "./AddItem";
import SearchItem from "./SearchItem";
import apiRequest from "./apiRequests";

function App() {
  // const [items, setItems] = useState([
  //   { id: 1, checked: true, description: "Practice Java" },
  //   { id: 2, checked: false, description: "Practice JS" },
  //   { id: 3, checked: true, description: "Practice React" },
  // ]);
  const [items, setItems] = useState(
    JSON.parse(localStorage.getItem("todo_list")) || []
  );

  const handleCheck = async (id) => {
    const listItems = items.map((item) =>
      item.id === id
        ? { id: item.id, checked: !item.checked, description: item.description }
        : item
    );
    setItems(listItems);
    console.log(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));

    const updatedItem = items.filter((item) => item.id === id);

    const putOptions = {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(updatedItem),
    };

    const response = await apiRequest(API_URL + id, putOptions);
    console.log(response);
    if (response instanceof Error) setIsError(response);
  };

  const deleteTask = (id) => {
    const listItems = items.filter((item) => item.id !== id);
    setItems(listItems);
    console.log(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  const addItem = async (description) => {
    const id = items[items.length - 1].id + 1;
    const addNewItem = { id: id, checked: false, description: description };
    const listItems = [...items, addNewItem];
    setItems(listItems);
    console.log(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));

    const postOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(addNewItem),
    };

    const response = await apiRequest(API_URL, postOptions);
    console.log(response);
    if (response instanceof Error) setIsError(response);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("submitted");
    console.log(newItem);
    if (!newItem) return;
    addItem(newItem);
    setNewItem("");
  };
  const [newItem, setNewItem] = useState();
  const [searchItem, setSearchItem] = useState("");

  const API_URL = "http://localhost:3500/db/";

  const [isError, setIsError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchItems = async () => {
      try {
        // const response = await fetch(API_URL);
        const response = await apiRequest(API_URL);
        const listItems = await response.json();
        console.log(listItems);
        setItems(listItems);
      } catch (err) {
        console.log(err);
        setIsError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    setTimeout(() => {
      fetchItems();
    }, 1000);
  }, []);

  return (
    <div className="App">
      <Header title="Demo App" />
      <AddItem
        newItem={newItem}
        setNewItem={setNewItem}
        handleSubmit={handleSubmit}
      />
      <SearchItem searchItem={searchItem} setSearchItem={setSearchItem} />
      <main>
        {isLoading && <p>Loading Items</p>}
        {isError && <p>{isError}</p>}
        {!isError && !isLoading && (
          <Content
            items={items.filter((item) =>
              item.description.toLowerCase().includes(searchItem.toLowerCase())
            )}
            handleCheck={handleCheck}
            deleteTask={deleteTask}
          />
        )}
      </main>
      <Footer length={items.length} />
    </div>
  );
}

export default App;

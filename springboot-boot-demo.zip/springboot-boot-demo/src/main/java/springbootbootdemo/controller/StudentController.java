package springbootbootdemo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springbootbootdemo.bean.Student;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("students")
public class StudentController {

    static List<Student> students = new ArrayList<>();

    static {
        Student student1 = new Student(1, "John", "Doe");
        Student student2 = new Student(2, "Peter", "Doe");
        students.add(student1);
        students.add(student2);
    }


    @GetMapping("hello-world")
    public String helloWorld() {
        return "Hello World!!!";
    }

    @GetMapping("student")
    public ResponseEntity<Student> getStudent() {
        Student student = new Student(1, "John", "Doe");
        return ResponseEntity.ok().body(student);
    }


    @GetMapping("query")
    public ResponseEntity<Student> getStudentByQuery(@RequestParam int id, @RequestParam String firstName) {
        Student student = new Student(id, firstName, "Doe");
        return ResponseEntity.ok().body(student);
    }

    @GetMapping
    public ResponseEntity<List<Student>> getStudents() {
        // select * from students;
        return ResponseEntity.ok().body(students);
    }

    @GetMapping("{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable("id") int studentID) {
        // select * from students where id = 1;
        Student student = students.get(studentID - 1);
        return ResponseEntity.ok().body(student);
    }

    @PostMapping("create")
    public ResponseEntity<Student> createStudent(@RequestBody Student student) {
        // insert into students (firstname,lastname) values ();
        student.setId(students.size() + 1);
        students.add(student);
        return new ResponseEntity<>(student, HttpStatus.CREATED);
    }

    @PutMapping("update/{id}")
    public ResponseEntity<Student> updateStudent(@RequestBody Student student
            , @PathVariable("id") int studentId) {
        // update student set () values () where id = ?;

        students.set(studentId - 1, student);
        return ResponseEntity.ok(student);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable("id") int studentId) {
        // delete from student where id = ?;

        students.remove(studentId);
        return new ResponseEntity<>("Student deleted successfully", HttpStatus.NO_CONTENT);
    }


}

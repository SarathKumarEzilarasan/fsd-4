package springbootbootdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import springbootbootdemo.bean.Student;

@SpringBootApplication
public class SpringbootBootDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootBootDemoApplication.class, args);

        Student student = new Student(1, "john", "doe");
        student.setId(100);
        student.getId();
    }

}

package com.example.employeeservice.service.impl;

import com.example.employeeservice.dto.ApiResponseDto;
import com.example.employeeservice.dto.DepartmentDto;
import com.example.employeeservice.dto.EmployeeDto;
import com.example.employeeservice.entity.Employee;
import com.example.employeeservice.repository.EmployeeRepository;
import com.example.employeeservice.service.EmployeeService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;
    private ModelMapper modelMapper;
//    private RestTemplate restTemplate;
    private ApiClient apiClient;

    @Override
    public EmployeeDto saveEmployee(EmployeeDto employeeDto) {
        Employee employee = modelMapper.map(employeeDto, Employee.class);
        return modelMapper.map(employeeRepository.save(employee), EmployeeDto.class);
    }

    @Override
    @CircuitBreaker(name="${spring.application.name}", fallbackMethod = "getDefaultDepartment")
    public ApiResponseDto getEmployee(Long employeeId) {
        EmployeeDto employeeDto = modelMapper.map(employeeRepository.findById(employeeId), EmployeeDto.class);

        // API call to department service based on the employee's department code
//        ResponseEntity<DepartmentDto> departmentDtoResponseEntity = restTemplate
//                .getForEntity("http://localhost:8080/api/departments/" + employeeDto.getDepartmentCode()
//                        , DepartmentDto.class);
//        DepartmentDto departmentDto = departmentDtoResponseEntity.getBody();


        DepartmentDto departmentDto = apiClient.getDepartment(employeeDto.getDepartmentCode());


        ApiResponseDto apiResponseDto = new ApiResponseDto();
        apiResponseDto.setEmployeeDto(employeeDto);
        apiResponseDto.setDepartmentDto(departmentDto);

        return apiResponseDto;
    }


    public ApiResponseDto getDefaultDepartment(Long employeeId, Exception exception){
        System.out.println("inside default method");
        EmployeeDto employeeDto = modelMapper.map(employeeRepository.findById(employeeId), EmployeeDto.class);

        DepartmentDto departmentDto = new DepartmentDto();
        departmentDto.setDepartmentName("default department");
        departmentDto.setDepartmentDescription("default department since department service is down");
        departmentDto.setDepartmentCode("default_department");

        ApiResponseDto apiResponseDto = new ApiResponseDto();
        apiResponseDto.setEmployeeDto(employeeDto);
        apiResponseDto.setDepartmentDto(departmentDto);

        return apiResponseDto;
    }
}

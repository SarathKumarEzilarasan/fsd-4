import React from "react";
import { useParams } from "react-router";

const TodoComponent = () => {
  const { id } = useParams();

  const pageTitle = () => {
    return id ? (
      <h2 className="text-center">Update Todo</h2>
    ) : (
      <h2 className="text-center">Add Todo</h2>
    );
  };

  const saveOrUpdateTodo = () => {};

  return (
    <div className="container">
      <div className="row">
        <div className="card col-md-6 offser-md-3">
          {pageTitle()}
          <div className="card-body">
            <form>
              <div className="form-group mb-2">
                <lable className="form-label">Todo Title:</lable>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter Todo Title"
                  name="title"
                />
              </div>
              <div className="form-group mb-2">
                <lable className="form-label">Todo Description:</lable>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter Todo Description"
                  name="description"
                />
              </div>
              <div className="form-group mb-2">
                <lable className="form-label">Todo Completed:</lable>
                <select className="form-control">
                  <option value="false">No</option>
                  <option value="true">Yes</option>
                </select>
              </div>
              <button
                className="btn btn-success"
                onClick={(e) => saveOrUpdateTodo(e)}
              >
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TodoComponent;

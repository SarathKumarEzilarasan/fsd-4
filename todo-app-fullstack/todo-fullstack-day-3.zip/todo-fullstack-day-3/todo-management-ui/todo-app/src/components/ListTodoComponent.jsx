import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import { useNavigate } from "react-router";
import { isAdminUser } from "../services/AuthService";
import {
  completeTodo,
  deleteTodo,
  getAllTodos,
  incompleteTodo,
} from "../services/TodoService";

const ListTodoComponent = () => {
  const [todos, setTodos] = useState([]);

  const navigate = useNavigate();

  const isAdmin = isAdminUser();

  useEffect(() => {
    listTodos();
  }, []);

  const listTodos = async () => {
    try {
      const response = await getAllTodos();
      setTodos(response.data);
    } catch (err) {
      console.error(error);
    }
  };

  function addTodo() {
    navigate("/add-todo");
  }

  function updateTodo(id) {
    navigate(`/update-todo/${id}`);
  }

  const removeTodo = async (id) => {
    try {
      const response = await deleteTodo(id);
      listTodos();
    } catch (error) {
      console.error(error);
    }
  };

  const markCompleteTodo = async (id) => {
    try {
      const response = await completeTodo(id);
      listTodos();
    } catch (error) {
      console.error(error);
    }
  };

  const markInCompleteTodo = async (id) => {
    try {
      const response = await incompleteTodo(id);
      listTodos();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="container">
      <h2 className="text-center">List of Todos</h2>
      <button className="btn btn-primary mb-2" onClick={addTodo}>
        Add Todo
      </button>
      <div>
        <table className="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Todo Title</th>
              <th>Todo Description</th>
              <th>Todo Completed</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {todos.map((todo) => (
              <tr key={todo.id}>
                <td>{todo.title}</td>
                <td>{todo.description}</td>
                <td>{todo.completed ? "YES" : "NO"}</td>
                <td>
                  {isAdmin && (
                    <button
                      className="btn btn-info"
                      onClick={() => updateTodo(todo.id)}
                    >
                      Update
                    </button>
                  )}
                  {isAdmin && (
                    <button
                      className="btn btn-danger"
                      style={{ marginLeft: "10px" }}
                      onClick={() => removeTodo(todo.id)}
                    >
                      Delete
                    </button>
                  )}
                  <button
                    className="btn btn-success"
                    style={{ marginLeft: "10px" }}
                    onClick={() => markCompleteTodo(todo.id)}
                  >
                    Complete
                  </button>
                  <button
                    className="btn btn-info"
                    style={{ marginLeft: "10px" }}
                    onClick={() => markInCompleteTodo(todo.id)}
                  >
                    In Complete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ListTodoComponent;

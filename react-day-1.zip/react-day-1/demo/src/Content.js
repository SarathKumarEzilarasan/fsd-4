import React, { useState } from "react";
import { FaTrash } from "react-icons/fa";
import ItemList from "./ItemList";

const Content = ({ items, handleCheck, deleteTask }) => {
  return (
    <main>
      {items.length ? (
        <ItemList
          items={items}
          handleCheck={handleCheck}
          deleteTask={deleteTask}
        />
      ) : (
        <p>List is empty</p>
      )}
    </main>
  );
};

export default Content;

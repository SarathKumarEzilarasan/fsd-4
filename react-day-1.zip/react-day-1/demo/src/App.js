import "./App.css";
import Header from "./Header";
import Content from "./Content";
import Footer from "./Footer";
import { useState } from "react";

function App() {
  const [items, setItems] = useState([
    { id: 1, checked: true, description: "Practice Java" },
    { id: 2, checked: false, description: "Practice JS" },
    { id: 3, checked: true, description: "Practice React" },
  ]);

  const handleCheck = (id) => {
    const listItems = items.map((item) =>
      item.id === id
        ? { id: item.id, checked: !item.checked, description: item.description }
        : item
    );
    setItems(listItems);
    console.log(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  const deleteTask = (id) => {
    const listItems = items.filter((item) => item.id !== id);
    setItems(listItems);
    console.log(listItems);
    localStorage.setItem("todo_list", JSON.stringify(listItems));
  };

  return (
    <div className="App">
      <Header title="Demo App" />
      <Content
        items={items}
        handleCheck={handleCheck}
        deleteTask={deleteTask}
      />
      <Footer length={items.length} />
    </div>
  );
}

export default App;

import React from "react";
import { Outlet } from "react-router";
import Footer from "./Footer";
import Header from "./Header";
import Nav from "./Nav";

const Layout = ({ search, setSearch }) => {
  return (
    <div className="App">
      <Header title="Demo App" />
      <Nav search={search} setSearch={setSearch} />
      <Outlet></Outlet>
      <Footer />
    </div>
  );
};

export default Layout;

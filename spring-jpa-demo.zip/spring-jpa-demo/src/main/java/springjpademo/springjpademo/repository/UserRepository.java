package springjpademo.springjpademo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import springjpademo.springjpademo.entity.User;

public interface UserRepository extends JpaRepository<User,Long> {
}

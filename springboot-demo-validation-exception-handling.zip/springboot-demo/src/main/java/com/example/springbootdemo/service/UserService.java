package com.example.springbootdemo.service;

import com.example.springbootdemo.dto.UserDto;
import com.example.springbootdemo.entity.User;

import java.util.List;

public interface UserService {
    UserDto createUser(UserDto userDto);

    List<UserDto> getAllUsers();

    UserDto getUser(Long userId);

    UserDto updateUser(UserDto userDto);

    void deleteUser(Long userId);
}

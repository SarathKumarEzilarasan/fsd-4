package com.example.springbootdemo.mapper;

import com.example.springbootdemo.dto.UserDto;
import com.example.springbootdemo.entity.User;

public class UserMapper {
    public static UserDto mapToUserDto(User user){
        UserDto userDto = new UserDto();
        userDto.setId(user.getId());
        userDto.setFirstName(user.getFirstName());
        userDto.setLastName(user.getLastName());
//        userDto.setEmail(user.getEmail());

        return userDto;
    }

    public static User mapToUser(UserDto userDto){
        User user = new User();
        user.setId(userDto.getId());
        user.setFirstName(userDto.getFirstName());
        user.setLastName(userDto.getLastName());
//        user.setEmail(userDto.getEmail());

        return user;
    }
}

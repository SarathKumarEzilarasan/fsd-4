public class Demo {


    public static void main(String[] args) {
        int x = 60;
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        //                          m  l          h

        System.out.println(binarySearch(arr, 0, arr.length - 1, x));
    }

    public static int binarySearch(int[] arr, int low, int high, int x) {
        if (low > high) {
            return -1;
        }
        int mid = (low + high) / 2;
        if (arr[mid] == x) {
            return mid;
        } else if (arr[mid] > x) {
            return binarySearch(arr, low, mid - 1, x);
        } else {
            return binarySearch(arr, mid + 1, high, x);
        }
    }
}
